Person_reID_pytorch
==============================
from Resnet-50->Part-based Convolutional Baseline

It is consistent with the new baseline result in several top-conference works, e.g., Beyond Part Models: Person Retrieval with Refined Part Pooling(ECCV18) and Camera Style Adaptation for Person Re-identification(CVPR18). And arrived Rank@1=93.24%, mAP=80.78% only with softmax loss and Part-based Convolutional Baseline(PCB) method!\
`1`.`Random Erasing Augmentation` has been added\
`2`.`Last Stride`has been adjusted 1\


## 文章解读

CSDN博客：[小白入门计算机视觉系列——ReID(一)：什么是ReID？如何做ReID？ReID数据集？ReID评测指标？](https://blog.csdn.net/wlx19970505/article/details/101051278)\

知乎：[小白入门系列——ReID(一)：什么是ReID？如何做ReID？ReID数据集？ReID评测指标？](https://zhuanlan.zhihu.com/p/83411679)








    
